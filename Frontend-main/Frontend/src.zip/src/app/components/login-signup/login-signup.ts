import { Component } from '@angular/core';

@Component({
  selector: 'app-login-signup',
  templateUrl: './login-signup.html',
  styleUrls: ['./login-signup.css']
})
export class LoginSignup {}
