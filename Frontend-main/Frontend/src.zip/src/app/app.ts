import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { LoginSignup } from "./components/login-signup/login-signup";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, LoginSignup],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('EventPalnner-FrontEnd');
}
